﻿CREATE TABLE [dbo].[employee] (
    [ID]    INT           IDENTITY (1, 1) NOT NULL,
    [Name]  NVARCHAR (20) NULL,
    [Email] NVARCHAR (20) NULL
);

